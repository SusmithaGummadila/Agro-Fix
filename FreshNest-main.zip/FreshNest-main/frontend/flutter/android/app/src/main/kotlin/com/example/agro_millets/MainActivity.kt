package com.example.fresh_nest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
