
import 'package:flutter/material.dart';

const Color blackColor = Color(0xFF020202);
const Color darkColor = Color(0xFF0d2818);
const Color semiDarkColor = Color(0xFF0d2818);
const Color lightColor = Color(0xFF058c42);
const Color accentColor = Color(0xFF16db65);
