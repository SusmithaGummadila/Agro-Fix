//* For Production
const String API_URL = "https://agromillets.adaptable.app/api";

//* For Wireless Debugging
// const String API_URL = "http://192.168.0.106:3000/api";

//* For Emulator
// const String API_URL = "http://10.0.2.2:3000/api";

//* For Real Device
// const String API_URL = "http://localhost:5050/api";
