function Loading() {
  return (
    <>
      <div className="flex items-center justify-center mt-20">
        <div className="loading loading-dots"></div>
      </div>
    </>
  );
}

export default Loading;
